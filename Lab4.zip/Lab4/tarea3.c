//abrir programa
//definir funcion float
//crear funcion main
//llamar funcion float 
//cerrar programa
#include <stdio.h>
float probabilidadpositivo
{
	float probabilidad;
	float probabilidadinfectado=0.00001;
	float probabilidaderror=0.0001;
	probabilidad=probabilidadinfectado/probabilidaderror;
	printf("si le sale positivo la probabilidad de que este enfermo es de %f",probabilidad);
	return(probabilidad);
}
int main ()
{
	float probabilidad;
	probabilidad=probabilidadpositivo;
	return 0;
}
	
