//abrir programa
//realizar la funcion void
//realizar funcion int
//llamar funcion
//cerrar programa 
#include <stdio.h>
void inverso(int numero1){
	int numero2,numero3,numero4,resto1,resto2,resto3;
	resto1=numero1%10;
	numero2=numero1-resto1;
	numero3=numero2/10;
	resto2=numero3%10;
	numero4=numero3-resto2;
	resto3=numero4/10;
	printf("%d",resto1);
	printf("%d",resto2);
	printf("%d",resto3);
}
int main (){
	int numero1;
	printf("ingrese un numero de 3 digitos\n");
	scanf("%d",&numero1);
	if(99<numero1 && numero1<1000){
		inverso(numero1);
	}
	else{
		printf("el numero ingresado no es valido");
	}
	return 0
}
	
	
	

