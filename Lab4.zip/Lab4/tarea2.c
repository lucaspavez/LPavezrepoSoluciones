//abrir programa
//realizar la funcion void
//realizar funcion void
//llamar funcion void
//cerrar programa
#include <stdio.h>
	void precio(){
	float huno=2.66666666, hjuan=5, hmanuel=3,resto1,resto2,pjuan,pmanuel;
	resto1=hjuan-huno;
	resto2=hmanuel-huno;
	pjuan=80*resto1/huno;
	pmanuel=80*resto2/huno;
	printf("a juan le tiene que pagar %f\n",pjuan);
	printf("a manuel le tiene que pagar %f",pmanuel);

}
void main ()
{
	precio();
	
}
